class Agent:
    def __init__(self, name, persona, llm):
        self.name = name
        self.persona = persona
        self.llm = llm

    def speak(self, message_history):
        prompt = f"""
You are {self.name}. Your personality:
{self.persona}

Continue the conversation. Respond naturally.
Conversation so far:
{message_history}
        """
        response = self.llm(prompt)
        return response.strip()
