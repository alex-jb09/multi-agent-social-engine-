import pandas as pd
import random

def load_mbti_sample(path="data/mbti_sample.csv"):
    return pd.read_csv(path)

def generate_persona(df):
    row = df.sample(1).iloc[0]
    return f"""
MBTI Type: {row['type']}
Typical behaviors: {row['posts'][:300]}
Communication style: reflective, emotional, opinion-driven.
"""
