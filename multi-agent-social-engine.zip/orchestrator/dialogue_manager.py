class DialogueManager:
    def __init__(self, agent1, agent2, max_turns=5):
        self.agent1 = agent1
        self.agent2 = agent2
        self.max_turns = max_turns
        self.history = ""

    def run(self):
        speaker = self.agent1
        for _ in range(self.max_turns):
            response = speaker.speak(self.history)
            self.history += f"\n{speaker.name}: {response}"
            speaker = self.agent2 if speaker == self.agent1 else self.agent1
        return self.history
