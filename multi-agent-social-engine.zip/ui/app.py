import streamlit as st
from agents.agent import Agent
from agents.persona_builder import load_mbti_sample, generate_persona
from orchestrator.dialogue_manager import DialogueManager

def fake_llm(prompt):
    return "Demo mode: LLM response coming soon."

st.title("🤖 Multi-Agent AI Social Interaction Engine")

df = load_mbti_sample()

if st.button("Generate Agents"):
    persona1 = generate_persona(df)
    persona2 = generate_persona(df)

    st.subheader("Agent 1 Persona")
    st.write(persona1)

    st.subheader("Agent 2 Persona")
    st.write(persona2)

    agent1 = Agent("Alice", persona1, fake_llm)
    agent2 = Agent("Bob", persona2, fake_llm)

    dm = DialogueManager(agent1, agent2)
    st.subheader("Conversation Simulation")
    st.write(dm.run())
