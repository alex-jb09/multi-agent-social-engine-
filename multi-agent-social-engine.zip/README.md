# Multi-Agent AI Social Interaction Engine

A multi-agent AI system where LLM-powered personas interact autonomously using distinct personality profiles.  
Includes dialogue orchestration, sentiment analysis, and an extensible architecture for memory and compatibility modules.

## ▶️ Running the Project
pip install -r requirements.txt
streamlit run ui/app.py
python main.py
